package br.com.bluesoft.desafiov3.pedido.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Data
@NoArgsConstructor
@Entity
public class MovimentoEstoque implements Serializable {

    private static final long serialVersionUID = 6032442207390262109L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pedido_id")
    private Long pedidoId;

    @Column(name = "quantidade_reservada")
    private Double quantidadeReservada;

    public MovimentoEstoque(Long pedidoId, Double quantidadeReservada) {
        this.pedidoId = pedidoId;
        this.quantidadeReservada = quantidadeReservada;
    }
}
