package br.com.bluesoft.desafiov3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Desafiov3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
