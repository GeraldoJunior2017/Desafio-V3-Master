insert into pedido (id, retirada_na_loja, forma_pagamento) values (1, true, 'CREDITO');

insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (1, 1, 'COCA-COLA', 10);

insert into pedido (id, retirada_na_loja, forma_pagamento) values (2, true, 'CREDITO');

insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (2, 2, 'FANTA', 4);

insert into pedido (id, retirada_na_loja, forma_pagamento) values (3, true, 'DEBITO');

insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (3, 3, 'PAÇOCA', 4);

insert into pedido (id, retirada_na_loja, forma_pagamento) values (4, true, 'DEBITO');

insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (4, 4, 'ALFACE', 4);

insert into pedido (id, retirada_na_loja, forma_pagamento) values (5, true, 'CHEQUE');

insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (5, 5, 'OVO', 4);

insert into pedido (id, retirada_na_loja, forma_pagamento) values (6, true, 'CHEQUE');

insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (6, 6, 'OMO-MULTIAÇÃO', 4);
insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (7, 6, 'DETERGENTE', 4);
insert into item_pedido (id, pedido_id, descricao_produto, quantidade) values (8, 6, 'LIMPA-VIDRO', 4);