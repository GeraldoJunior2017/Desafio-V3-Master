package br.com.bluesoft.desafiov3.pedido.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Optional;

@Data
@NoArgsConstructor
@Entity
@Table(name = "item_pedido")
public class ItemPedido implements Serializable {

    private static final long serialVersionUID = -926422800283767316L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnore
    private Pedido pedido;

    @Column(name = "descricao_produto")
    private String descricaoProduto;

    @Max(value = 50)
    private Double quantidade;

    public ItemPedido(Pedido pedido, String descricaoProduto, Double quantidade) {
        this.pedido = pedido;
        this.descricaoProduto = descricaoProduto;
        this.quantidade = quantidade;
    }

    public Optional<Long> getPedidoId() {
        if (pedido != null) {
            return Optional.of(pedido.getId());
        }
        return Optional.empty();
    }
}
