package br.com.bluesoft.desafiov3.pedido.web.view;

import br.com.bluesoft.desafiov3.pedido.model.ItemPedido;
import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ItemPedidoView implements Serializable {

    private static final long serialVersionUID = 4882104752804151109L;

    private Long id;
    private Long pedidoId;
    private String descricaoProduto;
    private Double quantidade;

    public ItemPedidoView(ItemPedido itemPedido) {
        this.id = itemPedido.getId();
        this.pedidoId = itemPedido.getPedidoId().orElse(null);
        this.quantidade = itemPedido.getQuantidade();
        this.descricaoProduto = itemPedido.getDescricaoProduto();
    }
}
