package br.com.bluesoft.desafiov3.pedido.business;

import br.com.bluesoft.desafiov3.pedido.model.MovimentoEstoque;
import br.com.bluesoft.desafiov3.pedido.model.Pedido;
import br.com.bluesoft.desafiov3.pedido.repository.MovimentoEstoqueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MovimentacaoEstoqueService {

    private final MovimentoEstoqueRepository movimentoEstoqueRepository;

    @Autowired
    public MovimentacaoEstoqueService(MovimentoEstoqueRepository movimentoEstoqueRepository) {
        this.movimentoEstoqueRepository = movimentoEstoqueRepository;
    }

    public void movimentarEstoque(final Pedido pedido) {
        MovimentoEstoque movimentoEstoque = new MovimentoEstoque(
                pedido.getId(),
                pedido.getQuantidadeReservada()
        );
        movimentoEstoqueRepository.save(movimentoEstoque);
    }
}
