package br.com.bluesoft.desafiov3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Desafiov3Application {

    public static void main(String[] args) {
        SpringApplication.run(Desafiov3Application.class, args);
    }

}
