package br.com.bluesoft.desafiov3.pedido.web.view;

import br.com.bluesoft.desafiov3.pedido.model.FormaPagamento;
import br.com.bluesoft.desafiov3.pedido.model.Pedido;
import lombok.*;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@NoArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class PedidoView implements Serializable {

    private static final long serialVersionUID = 8524411450893934833L;

    private Long id;
    private boolean retiradaNaLoja;
    private FormaPagamento formaPagamento;
    private List<ItemPedidoView> itens;

    public PedidoView(Pedido pedido) {
        this.id = pedido.getId();
        this.retiradaNaLoja = pedido.isRetiradaNaLoja();
        this.formaPagamento = pedido.getFormaPagamento();
        this.itens = pedido
                .getItens()
                .stream()
                .map(ItemPedidoView::new)
                .collect(Collectors.toList());
    }
}
