package br.com.bluesoft.desafiov3.pedido.web.form;

import br.com.bluesoft.desafiov3.pedido.model.FormaPagamento;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class PedidoFormulario implements Serializable {

    private static final long serialVersionUID = 6835250228121613313L;

    private boolean retiradaNaLoja;
    private boolean simularFalha;
    private FormaPagamento formaPagamento;
    private List<ItemPedidoFormulario> itens;
}
