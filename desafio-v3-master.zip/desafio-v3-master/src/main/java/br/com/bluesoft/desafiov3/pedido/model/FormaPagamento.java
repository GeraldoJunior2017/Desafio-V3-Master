package br.com.bluesoft.desafiov3.pedido.model;

public enum FormaPagamento {

    DEBITO, CREDITO, CHEQUE;
}
