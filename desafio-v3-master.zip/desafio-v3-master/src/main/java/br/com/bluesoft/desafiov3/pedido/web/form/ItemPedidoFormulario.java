package br.com.bluesoft.desafiov3.pedido.web.form;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ItemPedidoFormulario implements Serializable {

    private static final long serialVersionUID = -5972704688109359608L;

    private String descricaoProduto;
    private double quantidade;
}
