package br.com.bluesoft.desafiov3.pedido.repository;

import br.com.bluesoft.desafiov3.pedido.dtos.QuantidadeFormaPagamentoDto;
import br.com.bluesoft.desafiov3.pedido.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    @Query("select new br.com.bluesoft.desafiov3.pedido.dtos.QuantidadeFormaPagamentoDto(p.formaPagamento, count(1)) from Pedido p group by p.formaPagamento")
    List<QuantidadeFormaPagamentoDto> findQuantidadePedidoByFormaPagamento();
}
