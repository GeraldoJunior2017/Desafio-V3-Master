package br.com.bluesoft.desafiov3.pedido.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
public class Pedido implements Serializable {

    private static final long serialVersionUID = 8749210496113331344L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "retirada_na_loja")
    private boolean retiradaNaLoja;

    @Column(name = "forma_pagamento")
    @Enumerated(EnumType.STRING)
    private FormaPagamento formaPagamento;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private final List<ItemPedido> itens = new ArrayList<>();

    public Pedido(boolean retiradaNaLoja, FormaPagamento formaPagamento) {
        this.retiradaNaLoja = retiradaNaLoja;
        this.formaPagamento = formaPagamento;
    }

    public void addItem(String descricaoProduto, Double quantidade) {
        itens.add(new ItemPedido(this, descricaoProduto, quantidade));
    }

    public Double getQuantidadeReservada() {
        return itens.stream().map(ItemPedido::getQuantidade).reduce(Double::sum).orElse(0D);
    }
}
