package br.com.bluesoft.desafiov3.pedido.dtos;

import br.com.bluesoft.desafiov3.pedido.model.FormaPagamento;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class QuantidadeFormaPagamentoDto {

    FormaPagamento formaPagamento;
    Long quantidade;

    public QuantidadeFormaPagamentoDto(FormaPagamento formaPagamento, Long quantidade) {
        this.formaPagamento = formaPagamento;
        this.quantidade = quantidade;
    }
}
