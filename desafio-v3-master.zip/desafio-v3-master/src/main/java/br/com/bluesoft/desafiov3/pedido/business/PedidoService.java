package br.com.bluesoft.desafiov3.pedido.business;

import br.com.bluesoft.desafiov3.pedido.model.FormaPagamento;
import br.com.bluesoft.desafiov3.pedido.model.Pedido;
import br.com.bluesoft.desafiov3.pedido.model.exception.EstoqueVazioException;
import br.com.bluesoft.desafiov3.pedido.repository.PedidoRepository;
import br.com.bluesoft.desafiov3.pedido.web.form.PedidoFormulario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PedidoService {

    private final PedidoRepository repository;
    private final MovimentacaoEstoqueService movimentacaoEstoqueService;

    @Autowired
    public PedidoService(PedidoRepository repository, MovimentacaoEstoqueService movimentoEstoqueService) {
        this.repository = repository;
        this.movimentacaoEstoqueService = movimentoEstoqueService;
    }

    public Pedido novo(PedidoFormulario pedidoFormulario) throws EstoqueVazioException {
        Pedido pedido = new Pedido(
                pedidoFormulario.isRetiradaNaLoja(),
                pedidoFormulario.getFormaPagamento()
        );
        pedidoFormulario.getItens()
                .forEach(item -> pedido.addItem(item.getDescricaoProduto(), item.getQuantidade()));
        //simula falha não apague
        if (pedidoFormulario.isSimularFalha()) this.simularFalha();
        final Pedido pedidoCriado = repository.save(pedido);
        movimentacaoEstoqueService.movimentarEstoque(pedidoCriado);
        return pedidoCriado;
    }

    public List<Pedido> listar() {
        return repository.findAll();
    }

    public Pedido buscar(Long pedidoId) {
        return repository.findById(pedidoId).orElse(null);
    }

    public void deletar(Long pedidoId) {
        repository.deleteById(pedidoId);
    }

    public Map<FormaPagamento, Long> listarQuantidadeDePedidosPorFormaDePagamento() {
        HashMap<FormaPagamento, Long> quantityMap = new HashMap<>();
        repository.findQuantidadePedidoByFormaPagamento().forEach(fp -> quantityMap.put(fp.getFormaPagamento(), fp.getQuantidade()));
        return quantityMap;
    }

    private void simularFalha() throws EstoqueVazioException {
        throw new EstoqueVazioException();
    }
}
